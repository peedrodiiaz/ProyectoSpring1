package Estadisticas.controller;

public class EstadisticasController {
}
