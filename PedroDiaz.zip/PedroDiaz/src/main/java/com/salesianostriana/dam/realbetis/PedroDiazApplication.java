package com.salesianostriana.dam.realbetis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PedroDiazApplication {

	public static void main(String[] args) {
		SpringApplication.run(PedroDiazApplication.class, args);
	}

}
